#define MAX_CHOCOLATES 100 // Numero maximo de los productos
#define MAX_NOMBRE 70 // Longitud maxima del nombre del producto ingresado

// PROTOTIPOS
int agregarProducto(char [][MAX_NOMBRE], int [], float [], int);
void imprimirProductos(char [][MAX_NOMBRE], int [], float [], int);
void buscarProducto(char [][MAX_NOMBRE], int [], float [], int);
