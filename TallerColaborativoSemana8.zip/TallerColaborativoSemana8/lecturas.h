//DATOS ENTEROS
int leerEnteroPositivo(char*);
int leerEntero(char*);
int leerEnteroEntre(char*, int, int);
//DATOS FLOTANTES
float leerFlotante(char*);
float leerFlotantePositivo(char*);
float leerFlotanteEntre(char*, float, float);
float leerFlotanteMayorIgual(char*,float);
float leerFlotanteMenorIgual(char*,float);
//DATOS CARACTER
char leerCaracter(char*);